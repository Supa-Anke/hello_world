#!/usr/bin/env python

def funktion():
    print("Hello")

print("Virus")
